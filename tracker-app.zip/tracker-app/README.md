# Трекер первокурсника ИРИТ-РТФ УрФУ

Архитектура ровно как на схеме:

```
Браузер (HTML/JS) --HTTP/REST API--> Backend (FastAPI) --SQL--> PostgreSQL (profiles)
```

## Структура проекта

```
tracker-app/
├── docker-compose.yml
├── backend/
│   ├── Dockerfile
│   ├── requirements.txt
│   └── app/
│       ├── main.py        # FastAPI: REST-эндпоинты + отдача статики
│       ├── database.py    # подключение к PostgreSQL (SQLAlchemy)
│       └── models.py      # модель таблицы profiles
└── frontend/
    ├── index.html
    ├── style.css
    └── script.js          # тот же интерфейс, но данные хранятся не в
                            # localStorage, а синхронизируются с backend
```

## Запуск

Нужен Docker и Docker Compose.

```bash
cd tracker-app
docker compose up --build
```

Открыть в браузере: **http://localhost:8000**

При первом заходе backend создаст запись в таблице `profiles` и выставит
браузеру httpOnly-cookie `tracker_uid` — по ней сервер узнаёт пользователя
при следующих запросах. Никаких логинов/паролей нет, это прямая замена
localStorage на серверное хранилище, работающая для каждого браузера
отдельно (как и раньше).

## Как это устроено

- **Frontend** — тот же самый интерфейс трекера. Раньше `state`, `startDate`
  и `profile` читались и писались через `localStorage`, теперь — через
  `fetch()` к `/api/...`. Сама логика интерфейса (рендер, модалки, фильтры)
  не менялась.
- **Backend** — FastAPI. Пять эндпоинтов:
  - `GET  /api/bootstrap` — отдаёт всё сразу при загрузке страницы
  - `PUT  /api/state` — сохранить статусы задач
  - `PUT  /api/start-date` — сохранить дату начала отсчёта
  - `PUT  /api/profile` — сохранить/очистить анкету
  - `POST /api/reset` — полный сброс (кнопка «Сбросить» в интерфейсе)
- **PostgreSQL** — одна таблица `profiles`, по одной строке на пользователя.
  Анкета и статусы задач хранятся как JSONB-поля — список задач (`TASKS`)
  статический и как был зашит в JS, так и остался (это справочные данные,
  а не то, что меняет пользователь).

## Локальный запуск без Docker (для разработки)

```bash
# Postgres должен быть поднят отдельно, с базой/пользователем tracker/tracker
cd backend
pip install -r requirements.txt
DATABASE_URL=postgresql+psycopg2://tracker:tracker@localhost:5432/tracker \
  uvicorn app.main:app --reload --port 8000
```

Frontend в этом режиме нужно временно скопировать в `backend/frontend`
(либо поменять `directory="/app/frontend"` в `main.py` на относительный
путь `../frontend`).
